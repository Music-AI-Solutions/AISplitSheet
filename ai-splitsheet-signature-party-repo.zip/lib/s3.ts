import { S3Client, PutObjectCommand } from '@aws-sdk/client-s3';

export const s3 = new S3Client({ region: process.env.AWS_REGION });

export async function uploadPdfToS3(key: string, pdfBuffer: Buffer) {
  const bucket = process.env.S3_BUCKET!;
  await s3.send(new PutObjectCommand({ Bucket: bucket, Key: key, Body: pdfBuffer, ContentType: 'application/pdf', ACL: 'public-read' } as any));
  const base = process.env.PUBLIC_S3_BASE_URL || `https://${bucket}.s3.amazonaws.com`;
  return `${base}/${key}`;
}

export async function uploadObjectToS3(key: string, buffer: Buffer, contentType: string) {
  const bucket = process.env.S3_BUCKET!;
  await s3.send(new PutObjectCommand({ Bucket: bucket, Key: key, Body: buffer, ContentType: contentType, ACL: 'public-read' } as any));
  const base = process.env.PUBLIC_S3_BASE_URL || `https://${bucket}.s3.amazonaws.com`;
  return `${base}/${key}`;
}
