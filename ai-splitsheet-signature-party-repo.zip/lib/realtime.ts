import { createClient } from '@supabase/supabase-js';
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL as string;
const supabaseAnon = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY as string;
export const supabase = createClient(supabaseUrl, supabaseAnon);
export function eventChannel(eventId: string) {
  return supabase.channel(`event:${eventId}`, { config: { broadcast: { self: true }, presence: { key: Math.random().toString(36).slice(2) } } });
}
