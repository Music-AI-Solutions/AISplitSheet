-- Roblox Signature Pad (basic) - paste into LocalScript under a ScreenGui with a Frame named 'Pad'
local uis = game:GetService('UserInputService')
local pad = script.Parent:WaitForChild('Pad')
local drawing = false
local lastPos = nil

pad.InputBegan:Connect(function(input)
  if input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch then
    drawing = true
    lastPos = input.Position
  end
end)

pad.InputEnded:Connect(function(input)
  if input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch then
    drawing = false
    lastPos = nil
  end
end)

pad.InputChanged:Connect(function(input)
  if drawing and (input.UserInputType == Enum.UserInputType.MouseMovement or input.UserInputType == Enum.UserInputType.Touch) then
    local p1 = lastPos
    local p2 = input.Position
    if p1 and p2 then
      local l = Instance.new('Frame')
      l.BorderSizePixel = 0
      l.BackgroundColor3 = Color3.fromRGB(20,20,20)
      local dx = p2.X - p1.X
      local dy = p2.Y - p1.Y
      local len = math.max(1, math.sqrt(dx*dx + dy*dy))
      l.Size = UDim2.new(0, len, 0, 4)
      l.AnchorPoint = Vector2.new(0,0.5)
      l.Position = UDim2.fromOffset(p1.X - pad.AbsolutePosition.X, p1.Y - pad.AbsolutePosition.Y)
      l.Rotation = math.deg(math.atan2(dy, dx))
      l.Parent = pad
      lastPos = p2
    end
  end
end)
