# AI Split Sheet – Signature Party (Repo)

Run a collaborative signing event with WebXR signatures, e‑sign, and optional NFT minting.

## Quick Start
```bash
npm i
npm run dev
# then open http://localhost:3000/party/demo
```

## Env (.env.local)
See these keys:
- S3: `AWS_REGION`, `AWS_ACCESS_KEY_ID`, `AWS_SECRET_ACCESS_KEY`, `S3_BUCKET`, `PUBLIC_S3_BASE_URL`
- Supabase: `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY`
- DocuSign: `DOCUSIGN_BASE_PATH`, `DOCUSIGN_ACCOUNT_ID`, `DOCUSIGN_INTEGRATION_KEY`, `DOCUSIGN_USER_ID`, `DOCUSIGN_PRIVATE_KEY(base64)`, `DOCUSIGN_REDIRECT_URI`
- Dropbox Sign: `DROPBOXSIGN_API_KEY`
- thirdweb/Polygon: `THIRDWEB_SECRET_KEY`, `EVENT_NFT_CONTRACT`

## Folders
- `components/VRSignatureSandbox.tsx` – WebXR signature pad (mouse fallback)
- `components/LODWithSignature.tsx` – LOD editor + PDF + DocuSign
- `pages/party/[eventId].tsx` – PartyRoom (realtime, wallets, mint)
- `pages/api/*` – pdf, esign, upload, mint, mock event store
- `lib/*` – S3 + Supabase helpers
