import React, { useEffect, useRef, useState } from "react";
import * as THREE from "three";
import { Canvas, useFrame, useThree } from "@react-three/fiber";

export default function VRSignatureSandbox({ onExport }: { onExport?: (png: string) => void }) {
  const [mode, setMode] = useState<"vr" | "mouse">("mouse");
  return (
    <div className="min-h-[50vh] p-2">
      <div className="mb-2 flex gap-2 items-center">
        <select value={mode} onChange={(e)=>setMode(e.target.value as any)} className="border rounded px-2 py-1">
          <option value="vr">VR (WebXR)</option>
          <option value="mouse">Mouse</option>
        </select>
        <button onClick={()=>exportCanvas(onExport)} className="rounded border px-2 py-1">Export PNG</button>
      </div>
      <div className="rounded border overflow-hidden">
        <Canvas onCreated={({ gl }) => { gl.setClearColor("#f8fafc"); }} camera={{ position: [0, 0, 2], fov: 60 }}>
          <ambientLight />
          <SignaturePad mode={mode} />
        </Canvas>
      </div>
    </div>
  );
}

function SignaturePad({ mode }: { mode: "vr" | "mouse" }) {
  const { gl } = useThree();
  const points = useRef<THREE.Vector3[]>([]);
  const drawing = useRef(false);
  const ray = useRef(new THREE.Raycaster());
  const mouse = useRef(new THREE.Vector2());
  const lineRef = useRef<any>();

  useEffect(() => {
    const canvas = gl.domElement;
    const onDown = (e: PointerEvent) => { drawing.current = true; updateMouse(e); addPoint(); };
    const onMove = (e: PointerEvent) => { if (!drawing.current) return; updateMouse(e); addPoint(); };
    const onUp = () => { drawing.current = false; };
    canvas.addEventListener("pointerdown", onDown);
    window.addEventListener("pointermove", onMove);
    window.addEventListener("pointerup", onUp);
    return () => { canvas.removeEventListener("pointerdown", onDown); window.removeEventListener("pointermove", onMove); window.removeEventListener("pointerup", onUp); };
  }, [gl]);

  const updateMouse = (e: PointerEvent) => {
    const rect = gl.domElement.getBoundingClientRect();
    mouse.current.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    mouse.current.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
  };

  const addPoint = () => {
    const p = new THREE.Vector3(mouse.current.x, mouse.current.y, 0);
    points.current.push(p);
    const geo = new THREE.BufferGeometry().setFromPoints(points.current);
    // @ts-ignore
    if (lineRef.current) lineRef.current.geometry = geo;
  };

  useFrame(() => {});
  return <line ref={lineRef} geometry={new THREE.BufferGeometry()} material={new THREE.LineBasicMaterial({})} />;
}

function exportCanvas(onExport?: (png: string)=>void) {
  const canvas = document.querySelector("canvas") as HTMLCanvasElement | null;
  if (!canvas) return;
  const png = canvas.toDataURL("image/png");
  onExport?.(png);
  const a = document.createElement("a"); a.href = png; a.download = "vr-signature.png"; a.click();
}
