import type { NextApiRequest, NextApiResponse } from 'next';
import puppeteer from 'puppeteer';
import HelloSign from 'hellosign-sdk';
import { uploadPdfToS3 } from '../../../lib/s3';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  try {
    const { html, signerName, signerEmail, subject = 'Letter of Direction', message = 'Please sign the LOD' } = req.body || {};
    if (!html || !signerName || !signerEmail) return res.status(400).json({ error: 'Missing html, signerName, or signerEmail' });

    const browser = await puppeteer.launch({ args: ['--no-sandbox', '--disable-setuid-sandbox'] });
    const page = await browser.newPage();
    await page.setContent(html, { waitUntil: 'networkidle0' });
    const pdf = await page.pdf({ format: 'A4', printBackground: true, margin: { top: '18mm', bottom: '18mm', left: '16mm', right: '16mm' } });
    await browser.close();

    const key = `lod/${Date.now()}-${Math.random().toString(36).slice(2)}.pdf`;
    const url = await uploadPdfToS3(key, Buffer.from(pdf));

    const hs = HelloSign({ key: process.env.DROPBOXSIGN_API_KEY! });
    const response = await hs.signatureRequest.send({
      title: subject,
      subject,
      message,
      signers: [ { name: signerName, email_address: signerEmail } ],
      file_url: [ url ],
      test_mode: 1,
    } as any);

    return res.status(200).json({ signatureRequestId: (response as any).signature_request?.signature_request_id, fileUrl: url });
  } catch (e: any) {
    return res.status(500).json({ error: e?.message || 'sendFromHtml failed' });
  }
}
