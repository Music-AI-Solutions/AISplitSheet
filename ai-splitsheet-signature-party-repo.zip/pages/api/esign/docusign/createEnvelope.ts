import type { NextApiRequest, NextApiResponse } from 'next';
import * as docusign from 'docusign-esign';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  try {
    const { signerName, signerEmail, html, subject = 'Letter of Direction' } = req.body || {};
    if (!signerName || !signerEmail || !html) return res.status(400).json({ error: 'Missing signerName, signerEmail or html' });

    const apiClient = new docusign.ApiClient();
    apiClient.setBasePath(process.env.DOCUSIGN_BASE_PATH || 'https://demo.docusign.net/restapi');
    const jwt = await apiClient.requestJWTUserToken(
      process.env.DOCUSIGN_INTEGRATION_KEY!, 
      process.env.DOCUSIGN_USER_ID!, 
      'signature', 
      Buffer.from(process.env.DOCUSIGN_PRIVATE_KEY!, 'base64'), 
      3600
    );
    apiClient.addDefaultHeader('Authorization', 'Bearer ' + jwt.body.access_token);
    const envelopesApi = new docusign.EnvelopesApi(apiClient as any);

    const docBase64 = Buffer.from(html, 'utf8').toString('base64');
    const document = new docusign.Document();
    document.documentBase64 = docBase64;
    document.name = 'Letter of Direction';
    document.fileExtension = 'html';
    document.documentId = '1';

    const signer = new docusign.Signer();
    signer.email = signerEmail;
    signer.name = signerName;
    signer.recipientId = '1';
    signer.routingOrder = '1';

    // Place a generic SignHere tab at a fixed location (page 1)
    const signHere = new docusign.SignHere();
    signHere.pageNumber = '1';
    signHere.recipientId = '1';
    signHere.xPosition = '100';
    signHere.yPosition = '600';
    const tabs = new docusign.Tabs();
    tabs.signHereTabs = [signHere];
    (signer as any).tabs = tabs;

    const recipients = new docusign.Recipients();
    recipients.signers = [signer];

    const envelopeDefinition = new docusign.EnvelopeDefinition();
    envelopeDefinition.emailSubject = subject;
    envelopeDefinition.documents = [document];
    envelopeDefinition.recipients = recipients;
    envelopeDefinition.status = 'sent';

    const results = await envelopesApi.createEnvelope(process.env.DOCUSIGN_ACCOUNT_ID!, { envelopeDefinition });
    return res.status(200).json({ envelopeId: (results as any).envelopeId });
  } catch (e: any) {
    return res.status(500).json({ error: e?.message || 'DocuSign failed' });
  }
}
