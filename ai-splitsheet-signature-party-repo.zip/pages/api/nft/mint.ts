import type { NextApiRequest, NextApiResponse } from 'next';
import { ThirdwebSDK } from '@thirdweb-dev/sdk';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  try {
    const { toAddresses, metadata, treasuryAddress } = req.body || {};
    if (!Array.isArray(toAddresses) || toAddresses.length === 0) return res.status(400).json({ error: 'toAddresses[] required' });
    const contractAddress = process.env.EVENT_NFT_CONTRACT as string;
    if (!contractAddress) return res.status(500).json({ error: 'Missing EVENT_NFT_CONTRACT' });
    const sdk = ThirdwebSDK.fromPrivateKey(process.env.THIRDWEB_SECRET_KEY as string, 'polygon');
    const contract = await sdk.getContract(contractAddress);
    const receipts: any[] = [];
    for (const addr of toAddresses) receipts.push(await contract.erc721.mintTo(addr, metadata || { name: 'Signature Party NFT' }));
    if (treasuryAddress) receipts.push(await contract.erc721.mintTo(treasuryAddress, metadata || { name: 'Signature Party NFT' }));
    return res.status(200).json({ txHash: receipts[0]?.receipt?.transactionHash || null, count: receipts.length });
  } catch (e: any) {
    return res.status(500).json({ error: e?.message || 'Mint failed' });
  }
}
