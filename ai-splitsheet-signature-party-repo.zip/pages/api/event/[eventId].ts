import type { NextApiRequest, NextApiResponse } from 'next';
const store = new Map<string, any>();
export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const { eventId } = req.query as { eventId: string };
  if (!eventId) return res.status(400).json({ error: 'eventId required' });
  if (req.method === 'GET') return res.status(200).json({ event: store.get(eventId) || null });
  if (req.method === 'PUT') { store.set(eventId, req.body || {}); return res.status(200).json({ ok: true }); }
  return res.status(405).json({ error: 'Method not allowed' });
}
