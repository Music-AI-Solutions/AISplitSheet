import type { NextApiRequest, NextApiResponse } from 'next';
import formidable, { File } from 'formidable';
import fs from 'node:fs';
import { uploadObjectToS3 } from '../../../lib/s3';

export const config = { api: { bodyParser: false } };

function parseForm(req: NextApiRequest): Promise<{ fields: formidable.Fields; files: formidable.Files }>{
  const form = formidable({ multiples: false, maxFileSize: 1024 * 1024 * 10 });
  return new Promise((resolve, reject) => {
    form.parse(req, (err, fields, files) => (err ? reject(err) : resolve({ fields, files })));
  });
}

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  try {
    const { files } = await parseForm(req);
    const file = files['file'] as File | undefined;
    if (!file) return res.status(400).json({ error: 'Missing file (field "file")' });

    const buf = fs.readFileSync((file as any).filepath || (file as any).path);
    const ext = (file.originalFilename?.split('.').pop() || 'png').toLowerCase();
    const key = `signatures/${Date.now()}-${Math.random().toString(36).slice(2)}.${ext}`;
    const url = await uploadObjectToS3(key, buf, file.mimetype || 'image/png');

    try { fs.unlinkSync((file as any).filepath || (file as any).path); } catch {}
    return res.status(200).json({ url });
  } catch (e: any) {
    return res.status(500).json({ error: e?.message || 'Upload failed' });
  }
}
