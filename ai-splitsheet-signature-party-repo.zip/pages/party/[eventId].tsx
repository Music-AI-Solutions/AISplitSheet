import React, { useMemo, useState, useEffect } from 'react';
import type { NextPage } from 'next';
import { useRouter } from 'next/router';
import { eventChannel } from '../api_references/realtime_client';
import dynamic from 'next/dynamic';

// Import real VR component (dynamic to avoid SSR issues)
const VRSignatureSandbox = dynamic(() => import('@/components/VRSignatureSandbox'), { ssr: false }) as any;

type Contributor = {
  id: string;
  name: string;
  role: 'Artist' | 'Producer' | 'Writer' | 'Engineer' | string;
  splitWriting?: number;
  splitMaster?: number;
  signatureUrl?: string;
  signerEmail?: string;
  wallet?: string;
};

type EventData = {
  id: string;
  title: string;
  artworkUrl?: string;
  contributors: Contributor[];
  treasuryAddress?: string;
  royaltyBps?: number;
};

const PartyRoomPage: NextPage = () => {
  const router = useRouter();
  const { eventId } = router.query as { eventId: string };
  const [event, setEvent] = useState<EventData>({
    id: eventId || 'demo',
    title: 'Signature Party – Demo Session',
    contributors: [
      { id: '1', name: 'Lead Artist', role: 'Artist', splitMaster: 50, splitWriting: 40, signerEmail: 'artist@example.com', wallet: '' },
      { id: '2', name: 'Producer A', role: 'Producer', splitMaster: 30, splitWriting: 30, signerEmail: 'producer@example.com', wallet: '' },
      { id: '3', name: 'Writer B', role: 'Writer', splitMaster: 20, splitWriting: 30, signerEmail: 'writer@example.com', wallet: '' },
    ],
    treasuryAddress: '',
    royaltyBps: 500,
  });

  useEffect(() => {
    if (!eventId) return;
    (async () => {
      try { const r = await fetch(`/api/event/${eventId}`); const d = await r.json(); if (d?.event) setEvent(d.event); } catch {}
    })();
  }, [eventId]);

  const signedCount = useMemo(() => event.contributors.filter(c => !!c.signatureUrl).length, [event]);
  const allSigned = signedCount === event.contributors.length && event.contributors.length > 0;

  const [online, setOnline] = useState<number>(1);
  useEffect(() => {
    if (!event.id) return;
    const ch = eventChannel(event.id);
    ch.on('presence', { event: 'sync' }, () => {
      const state = ch.presenceState();
      const total = Object.values(state).reduce((acc: number, arr: any) => acc + (arr?.length || 0), 0);
      setOnline(Math.max(1, total));
    });
    ch.subscribe(async (status) => { if (status === 'SUBSCRIBED') ch.track({ user: 'guest', at: Date.now() }); });
    ch.on('broadcast', { event: 'signature_added' }, ({ payload }) => {
      const { contributorId, url } = payload as { contributorId: string; url: string };
      setEvent((prev) => ({ ...prev, contributors: prev.contributors.map((c) => c.id === contributorId ? { ...c, signatureUrl: url } : c) }));
    });
    return () => { ch.unsubscribe(); };
  }, [event.id]);

  const saveEvent = async () => {
    try { const r = await fetch(`/api/event/${event.id}`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(event) }); if (!r.ok) throw new Error('Save failed'); alert('Saved!'); } catch (e: any) { alert(e.message); }
  };

  const handleExport = async (pngDataUrl: string) => {
    try {
      const blob = await (await fetch(pngDataUrl)).blob();
      const form = new FormData();
      form.append('file', blob, 'signature.png');
      const r = await fetch('/api/signature/upload', { method: 'POST', body: form });
      const data = await r.json();
      if (!r.ok) throw new Error(data.error || 'Upload failed');
      const next = event.contributors.find(c => !c.signatureUrl);
      if (!next) return;
      const updated = event.contributors.map(c => c.id === next.id ? { ...c, signatureUrl: data.url } : c);
      setEvent({ ...event, contributors: updated });
      try { const ch = eventChannel(event.id); await ch.send({ type: 'broadcast', event: 'signature_added', payload: { contributorId: next.id, url: data.url } }); } catch {}
    } catch (e: any) { alert('Signature upload error: ' + e.message); }
  };

  const getLODHtml = () => {
    const rows = event.contributors.map(c => `
      <tr>
        <td style="padding:6px 8px; border-bottom:1px solid #eee;">${c.name}</td>
        <td style="padding:6px 8px; border-bottom:1px solid #eee;">${c.role}</td>
        <td style="padding:6px 8px; border-bottom:1px solid #eee; text-align:right;">${c.splitMaster ?? '-'}%</td>
        <td style="padding:6px 8px; border-bottom:1px solid #eee; text-align:right;">${c.splitWriting ?? '-'}%</td>
        <td style="padding:6px 8px; border-bottom:1px solid #eee;">${c.signatureUrl ? `<img src="${c.signatureUrl}" style="max-height:56px">` : ''}</td>
      </tr>`).join('');
    return `<!doctype html><html><head><meta charset="utf-8"><title>${event.title}</title>
    <style>body{font-family:Arial,Helvetica,sans-serif;line-height:1.5;padding:24px;color:#111} h1{font-size:22px;margin:0 0 16px} .muted{color:#666;font-size:12px}</style>
    </head><body><h1>${event.title}</h1><p class="muted">Generated at ${new Date().toLocaleString()}</p>
    <table cellspacing="0" cellpadding="0" style="width:100%; border-collapse:collapse; margin-top:12px">
    <thead><tr><th style="text-align:left;padding:6px 8px;border-bottom:1px solid #ddd;">Name</th>
    <th style="text-align:left;padding:6px 8px;border-bottom:1px solid #ddd;">Role</th>
    <th style="text-align:right;padding:6px 8px;border-bottom:1px solid #ddd;">Master %</th>
    <th style="text-align:right;padding:6px 8px;border-bottom:1px solid #ddd;">Writing %</th>
    <th style="text-align:left;padding:6px 8px;border-bottom:1px solid #ddd;">Signature</th></tr></thead><tbody>${rows}</tbody></table></body></html>`;
  };

  const createPdf = async () => {
    const html = getLODHtml();
    const r = await fetch('/api/pdf/render', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ html }) });
    if (!r.ok) { const d = await r.json(); alert('PDF error: ' + (d.error || 'unknown')); return; }
    const blob = await r.blob(); const url = URL.createObjectURL(blob); window.open(url, '_blank');
  };

  const sendViaDocuSign = async () => {
    const html = getLODHtml();
    const signer = event.contributors[0];
    const r = await fetch('/api/esign/docusign/createEnvelope', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ signerName: signer.name, signerEmail: signer.signerEmail || 'changeme@example.com', html, subject: event.title }) });
    const d = await r.json();
    if (!r.ok) { alert('DocuSign error: ' + (d.error || 'unknown')); return; }
    alert('Envelope created: ' + d.envelopeId);
  };

  const sendViaDropboxSign = async () => {
    const html = getLODHtml();
    const signer = event.contributors[0];
    const r = await fetch('/api/esign/dropboxsign/sendFromHtml', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ signerName: signer.name, signerEmail: signer.signerEmail || 'changeme@example.com', html, subject: event.title, message: 'Please sign the LOD' }) });
    const d = await r.json();
    if (!r.ok) { alert('Dropbox Sign error: ' + (d.error || 'unknown')); return; }
    alert(`Signature Request: ${d.signatureRequestId}\nPDF: ${d.fileUrl}`);
  };

  const mintEventNFT = async () => {
    const toAddresses = event.contributors.map(c => c.wallet).filter(Boolean) as string[];
    if (!allSigned) { alert('All signatures required before minting.'); return; }
    if (toAddresses.length === 0) { alert('No wallets on contributors.'); return; }
    const metadata = {
      name: event.title,
      description: `Signature Party for ${event.title} (${event.id})`,
      image: event.contributors.find(c => c.signatureUrl)?.signatureUrl || event.artworkUrl || undefined,
      attributes: [
        { trait_type: 'Type', value: 'Signature Party' },
        { trait_type: 'Contributors', value: event.contributors.length },
        { trait_type: 'All Signed', value: true },
      ],
      royaltyBps: event.royaltyBps || 0,
      treasury: event.treasuryAddress || undefined,
      contributors: event.contributors.map(c => ({ name: c.name, role: c.role, wallet: c.wallet, splitMaster: c.splitMaster, splitWriting: c.splitWriting, signature: c.signatureUrl })),
    };
    const r = await fetch('/api/nft/mint', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ toAddresses, metadata, treasuryAddress: event.treasuryAddress }) });
    const d = await r.json();
    if (!r.ok) { alert('Mint error: ' + (d.error || 'unknown')); return; }
    alert(`Minted! tx: ${d.txHash || 'ok'}`);
  };

  return (
    <div className="min-h-screen bg-neutral-50 text-neutral-900 p-6">
      <div className="mx-auto max-w-6xl space-y-6">
        <header className="flex items-center justify-between gap-3 flex-wrap">
          <div><h1 className="text-2xl md:text-3xl font-semibold">{event.title}</h1><p className="text-sm opacity-70">Event ID: {event.id}</p></div>
          <div className="flex gap-2 items-center">
            <div className="text-sm rounded-full bg-neutral-200 px-3 py-1">👥 Online: {online}</div>
            <button onClick={saveEvent} className="rounded-2xl bg-neutral-900 px-4 py-2 text-white shadow">Save</button>
            <button onClick={createPdf} className="rounded-2xl bg-blue-600 px-4 py-2 text-white shadow">Preview PDF</button>
            <button onClick={sendViaDocuSign} className="rounded-2xl bg-amber-600 px-4 py-2 text-white shadow">DocuSign</button>
            <button onClick={sendViaDropboxSign} className="rounded-2xl bg-emerald-700 px-4 py-2 text-white shadow">Dropbox Sign</button>
          </div>
        </header>

        <section className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 rounded-2xl border bg-white p-4 shadow-sm">
            <h2 className="text-lg font-semibold mb-2">VR Signature Stage</h2>
            <VRSignatureSandbox onExport={(png: string) => handleExport(png)} />
            <p className="text-xs opacity-70 mt-2">Tip: Each export assigns the signature to the next unsigned contributor (demo logic). Replace with per-user auth in production.</p>
          </div>

          <div className="rounded-2xl border bg-white p-4 shadow-sm">
            <h2 className="text-lg font-semibold mb-2">Status Board</h2>
            <ul className="divide-y">
              {event.contributors.map((c, idx) => (
                <li key={c.id} className="py-3 flex items-center justify-between gap-3">
                  <div className="min-w-0">
                    <div className="font-medium truncate">{c.name} <span className="text-xs opacity-60">({c.role})</span></div>
                    <div className="text-xs opacity-70">Master {c.splitMaster ?? 0}% · Writing {c.splitWriting ?? 0}%</div>
                    <div className="mt-1 flex items-center gap-2">
                      <input placeholder={`Wallet address for ${c.name}`} className="w-full rounded border px-2 py-1 text-xs" value={c.wallet || ''}
                        onChange={(e)=>setEvent({ ...event, contributors: event.contributors.map((x,i)=> i===idx ? { ...x, wallet: e.target.value } : x) })} />
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    {c.signatureUrl ? <img src={c.signatureUrl} className="h-10 border rounded" /> : <span className="text-xs bg-neutral-100 rounded px-2 py-1">pending</span>}
                  </div>
                </li>
              ))}
            </ul>
            <div className="mt-3 text-sm">Signed: {signedCount} / {event.contributors.length}</div>
            {allSigned && <div className="mt-2 text-sm text-green-700">All signatures captured. You can finalize now.</div>}
            <div className="mt-4 grid grid-cols-1 gap-3">
              <div className="flex flex-wrap items-center gap-2"><label className="text-sm w-40">Treasury address</label>
                <input className="flex-1 rounded border px-2 py-1" placeholder="0x..." value={event.treasuryAddress || ''} onChange={(e)=>setEvent({ ...event, treasuryAddress: e.target.value })} /></div>
              <div className="flex flex-wrap items-center gap-2"><label className="text-sm w-40">Royalty (bps)</label>
                <input type="number" className="w-32 rounded border px-2 py-1" min={0} max={10000} value={event.royaltyBps ?? 0} onChange={(e)=>setEvent({ ...event, royaltyBps: parseInt(e.target.value || '0') })} />
                <span className="text-xs opacity-70">500 = 5%</span></div>
              <button onClick={mintEventNFT} disabled={!allSigned} className="rounded-2xl bg-purple-700 px-4 py-2 text-white shadow disabled:opacity-50">Mint Event NFT</button>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
};

export default PartyRoomPage;
